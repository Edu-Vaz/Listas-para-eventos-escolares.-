﻿using ListaDB;
using Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Home
{
    public partial class RegistrarVenda : Form
    {
        public RegistrarVenda()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Voltarbutton_Click(object sender, EventArgs e)
        {
            Home novoFormulario = new Home();

            // Exibir o novo formulário
            novoFormulario.Show();
        }

      

        private void pesquisar_Click(object sender, EventArgs e)
        {
            var alunos = new AlunosDB();
            string nomeSobrenome = NometextBox1.Text;
            
            // Supondo que você tenha uma instância da classe com o método Pesquisar_nome_Alunos
            List<Alunos> resultadoPesquisa = AlunosDB.Pesquisar_nome_Alunos(nomeSobrenome);

            // Limpar itens existentes na ListBox
            AlunoslistBox1.Items.Clear();

            // Adicionar os resultados à ListBox
            foreach (var aluno in resultadoPesquisa)
            {
                AlunoslistBox1.Items.Add($"ID: {aluno.MA}, Nome: {aluno.Nome}, Série: {aluno.Serie}");

            }
        }
        private void AlunoslistBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        

        private void PesquisarMAbutton_Click_1(object sender, EventArgs e)
        {
            var alunos = new AlunosDB();
            
            int ma = Convert.ToInt32(MatextBox2.Text);

            // Supondo que você tenha uma instância da classe com o método Pesquisar_nome_Alunos
            List<Alunos> resultadoPesquisa = AlunosDB.Pesquisar_nome_Alunos(ma);

            // Limpar itens existentes na ListBox
            AlunoslistBox1.Items.Clear();

            // Adicionar os resultados à ListBox
            foreach (var aluno in resultadoPesquisa)
            {
                AlunoslistBox1.Items.Add($"MA: {aluno.MA}, Nome: {aluno.Nome}, Série: {aluno.Serie}");
            }
        }

        private void RegistrarVendaButton_Click(object sender, EventArgs e)
        {
            var venda = new Venda();

            if (AlunoslistBox1.SelectedIndex != -1)
            {
                string itemSelecionado = AlunoslistBox1.SelectedItem.ToString();

                Match match = Regex.Match(itemSelecionado, @"MA: (\d+)");

                if (match.Success)
                {
                    int maSelecionado = int.Parse(match.Groups[1].Value); // Ajuste aqui para acessar o grupo correto
                    venda.Ma = maSelecionado;
                }
            }

            venda.Quantidade = Convert.ToInt32(QuanttextBox3.Text);
            DateTime data = monthCalendar1.SelectionStart;
            venda.Data = data.ToString("yyyy MM dd");

            var vendaDB = new VendaDB();
            vendaDB.Registrar_Venda(venda);
        }

        private void RegistrarVendabutton_Click_1(object sender, EventArgs e)
        {
            var venda = new Venda();

            if (AlunoslistBox1.SelectedIndex != -1)
            {
                string itemSelecionado = AlunoslistBox1.SelectedItem.ToString();

                Match match = Regex.Match(itemSelecionado, @"MA: (\d+)");

                if (match.Success)
                {
                    int maSelecionado = int.Parse(match.Groups[1].Value); // Ajuste aqui para acessar o grupo correto
                    venda.Ma = maSelecionado;
                }
            }

            venda.Quantidade = Convert.ToInt32(QuanttextBox3.Text);
            DateTime data = monthCalendar1.SelectionStart;
            venda.Data = data.ToString("yyyy-MM-dd");
            var vendaDB = new VendaDB();
            vendaDB.Registrar_Venda(venda);
            MessageBox.Show("Venda feita com exito");

        }

        private void Limpar_Click(object sender, EventArgs e)
        {
            NometextBox1.Clear();
            MatextBox2.Clear();
            QuanttextBox3.Clear();
        }

        private void NometextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
