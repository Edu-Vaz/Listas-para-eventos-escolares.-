﻿namespace Home
{
    partial class ConsultarAlunos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.matextBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.nometextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.Pesquisarbutton = new System.Windows.Forms.Button();
            this.Ordenar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // matextBox
            // 
            this.matextBox.Location = new System.Drawing.Point(583, 40);
            this.matextBox.Name = "matextBox";
            this.matextBox.Size = new System.Drawing.Size(83, 20);
            this.matextBox.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(434, 40);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(133, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "Pesquise o aluno pelo MA:";
            // 
            // nometextBox
            // 
            this.nometextBox.Location = new System.Drawing.Point(174, 37);
            this.nometextBox.Name = "nometextBox";
            this.nometextBox.Size = new System.Drawing.Size(240, 20);
            this.nometextBox.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(143, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Pesquise o aluno pelo nome:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(1, 130);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1180, 637);
            this.dataGridView1.TabIndex = 14;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Gold;
            this.button1.Location = new System.Drawing.Point(21, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 18;
            this.button1.Text = "Voltar";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // Pesquisarbutton
            // 
            this.Pesquisarbutton.Location = new System.Drawing.Point(28, 82);
            this.Pesquisarbutton.Name = "Pesquisarbutton";
            this.Pesquisarbutton.Size = new System.Drawing.Size(83, 42);
            this.Pesquisarbutton.TabIndex = 20;
            this.Pesquisarbutton.Text = "Pesquisar";
            this.Pesquisarbutton.UseVisualStyleBackColor = true;
            this.Pesquisarbutton.Click += new System.EventHandler(this.Pesquisarbutton_Click);
            // 
            // Ordenar
            // 
            this.Ordenar.BackgroundImage = global::Home.Properties.Resources.ordenar;
            this.Ordenar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Ordenar.FlatAppearance.BorderSize = 0;
            this.Ordenar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Ordenar.Location = new System.Drawing.Point(1080, 62);
            this.Ordenar.Name = "Ordenar";
            this.Ordenar.Size = new System.Drawing.Size(66, 62);
            this.Ordenar.TabIndex = 19;
            this.Ordenar.UseVisualStyleBackColor = true;
            this.Ordenar.Click += new System.EventHandler(this.Ordenar_Click);
            // 
            // ConsultarAlunos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1184, 761);
            this.Controls.Add(this.Pesquisarbutton);
            this.Controls.Add(this.Ordenar);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.matextBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.nometextBox);
            this.Controls.Add(this.label1);
            this.Name = "ConsultarAlunos";
            this.Text = "ConsultarAlunos";
            this.Load += new System.EventHandler(this.ConsultarAlunos_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox matextBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox nometextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button Ordenar;
        private System.Windows.Forms.Button Pesquisarbutton;
    }
}