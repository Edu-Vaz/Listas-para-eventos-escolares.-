﻿namespace Home
{
    partial class Home
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Home));
            this.panel1 = new System.Windows.Forms.Panel();
            this.NovoAlunobutton = new System.Windows.Forms.Button();
            this.Sair = new System.Windows.Forms.Button();
            this.ConsultarCompras = new System.Windows.Forms.Button();
            this.ConsultarAlunos = new System.Windows.Forms.Button();
            this.RegistrarVenda = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.EstoqueLabel = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.QuantLabel = new System.Windows.Forms.Label();
            this.UltimasVendasdataGridView1 = new System.Windows.Forms.DataGridView();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.Recarregar = new System.Windows.Forms.Button();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.UltimasVendasdataGridView1)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.panel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel1.BackColor = System.Drawing.Color.Gold;
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.pictureBox9);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.NovoAlunobutton);
            this.panel1.Controls.Add(this.Sair);
            this.panel1.Controls.Add(this.ConsultarCompras);
            this.panel1.Controls.Add(this.pictureBox8);
            this.panel1.Controls.Add(this.ConsultarAlunos);
            this.panel1.Controls.Add(this.RegistrarVenda);
            this.panel1.ForeColor = System.Drawing.Color.Yellow;
            this.panel1.Location = new System.Drawing.Point(0, 155);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(183, 577);
            this.panel1.TabIndex = 0;
            // 
            // NovoAlunobutton
            // 
            this.NovoAlunobutton.BackColor = System.Drawing.Color.Gold;
            this.NovoAlunobutton.Dock = System.Windows.Forms.DockStyle.Top;
            this.NovoAlunobutton.ForeColor = System.Drawing.Color.Black;
            this.NovoAlunobutton.Location = new System.Drawing.Point(0, 150);
            this.NovoAlunobutton.Name = "NovoAlunobutton";
            this.NovoAlunobutton.Size = new System.Drawing.Size(183, 50);
            this.NovoAlunobutton.TabIndex = 1;
            this.NovoAlunobutton.Text = "Novo aluno";
            this.NovoAlunobutton.UseVisualStyleBackColor = false;
            this.NovoAlunobutton.Click += new System.EventHandler(this.NovoAlunobutton_Click);
            // 
            // Sair
            // 
            this.Sair.BackColor = System.Drawing.Color.Red;
            this.Sair.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.Sair.ForeColor = System.Drawing.Color.White;
            this.Sair.Location = new System.Drawing.Point(0, 542);
            this.Sair.Name = "Sair";
            this.Sair.Size = new System.Drawing.Size(183, 35);
            this.Sair.TabIndex = 15;
            this.Sair.Text = "Sair";
            this.Sair.UseVisualStyleBackColor = false;
            this.Sair.Click += new System.EventHandler(this.Sair_Click);
            // 
            // ConsultarCompras
            // 
            this.ConsultarCompras.BackColor = System.Drawing.Color.Gold;
            this.ConsultarCompras.Dock = System.Windows.Forms.DockStyle.Top;
            this.ConsultarCompras.ForeColor = System.Drawing.Color.Black;
            this.ConsultarCompras.Location = new System.Drawing.Point(0, 100);
            this.ConsultarCompras.Name = "ConsultarCompras";
            this.ConsultarCompras.Size = new System.Drawing.Size(183, 50);
            this.ConsultarCompras.TabIndex = 13;
            this.ConsultarCompras.Text = "Consultar compras";
            this.ConsultarCompras.UseVisualStyleBackColor = false;
            this.ConsultarCompras.Click += new System.EventHandler(this.ConsultarCompras_Click);
            // 
            // ConsultarAlunos
            // 
            this.ConsultarAlunos.BackColor = System.Drawing.Color.Gold;
            this.ConsultarAlunos.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ConsultarAlunos.Dock = System.Windows.Forms.DockStyle.Top;
            this.ConsultarAlunos.FlatAppearance.BorderSize = 0;
            this.ConsultarAlunos.ForeColor = System.Drawing.Color.Black;
            this.ConsultarAlunos.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ConsultarAlunos.Location = new System.Drawing.Point(0, 50);
            this.ConsultarAlunos.Name = "ConsultarAlunos";
            this.ConsultarAlunos.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ConsultarAlunos.Size = new System.Drawing.Size(183, 50);
            this.ConsultarAlunos.TabIndex = 5;
            this.ConsultarAlunos.Text = "Consultar alunos";
            this.ConsultarAlunos.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.ConsultarAlunos.UseVisualStyleBackColor = false;
            this.ConsultarAlunos.UseWaitCursor = true;
            this.ConsultarAlunos.Click += new System.EventHandler(this.ConsultarAlunos_Click);
            // 
            // RegistrarVenda
            // 
            this.RegistrarVenda.BackColor = System.Drawing.Color.Gold;
            this.RegistrarVenda.Dock = System.Windows.Forms.DockStyle.Top;
            this.RegistrarVenda.ForeColor = System.Drawing.Color.Black;
            this.RegistrarVenda.Location = new System.Drawing.Point(0, 0);
            this.RegistrarVenda.Name = "RegistrarVenda";
            this.RegistrarVenda.Size = new System.Drawing.Size(183, 50);
            this.RegistrarVenda.TabIndex = 3;
            this.RegistrarVenda.Text = "Registrar venda";
            this.RegistrarVenda.UseVisualStyleBackColor = false;
            this.RegistrarVenda.Click += new System.EventHandler(this.RegistrarVenda_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label2.Location = new System.Drawing.Point(67, 126);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "User 1";
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Edwardian Script ITC", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(995, 50);
            this.label1.TabIndex = 1;
            this.label1.Text = "Bem vindo ao sistema de gerenciamento ";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.Recarregar);
            this.panel2.Controls.Add(this.EstoqueLabel);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.QuantLabel);
            this.panel2.Controls.Add(this.UltimasVendasdataGridView1);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Location = new System.Drawing.Point(189, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(995, 758);
            this.panel2.TabIndex = 2;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // EstoqueLabel
            // 
            this.EstoqueLabel.AutoSize = true;
            this.EstoqueLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EstoqueLabel.Location = new System.Drawing.Point(646, 78);
            this.EstoqueLabel.Name = "EstoqueLabel";
            this.EstoqueLabel.Size = new System.Drawing.Size(20, 24);
            this.EstoqueLabel.TabIndex = 10;
            this.EstoqueLabel.Text = "#";
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("HoloLens MDL2 Assets", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(582, 78);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(70, 30);
            this.label7.TabIndex = 9;
            this.label7.Text = "Estoque:";
            // 
            // QuantLabel
            // 
            this.QuantLabel.AutoSize = true;
            this.QuantLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.QuantLabel.Location = new System.Drawing.Point(465, 78);
            this.QuantLabel.Name = "QuantLabel";
            this.QuantLabel.Size = new System.Drawing.Size(20, 24);
            this.QuantLabel.TabIndex = 8;
            this.QuantLabel.Text = "#";
            // 
            // UltimasVendasdataGridView1
            // 
            this.UltimasVendasdataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.UltimasVendasdataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.UltimasVendasdataGridView1.Location = new System.Drawing.Point(16, 187);
            this.UltimasVendasdataGridView1.Name = "UltimasVendasdataGridView1";
            this.UltimasVendasdataGridView1.Size = new System.Drawing.Size(967, 143);
            this.UltimasVendasdataGridView1.TabIndex = 7;
            this.UltimasVendasdataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.UltimasVendasdataGridView1_CellContentClick);
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("HoloLens MDL2 Assets", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(474, 152);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(114, 30);
            this.label6.TabIndex = 6;
            this.label6.Text = "Ultimas vendas:";
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("HoloLens MDL2 Assets", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(278, 78);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(207, 30);
            this.label5.TabIndex = 5;
            this.label5.Text = "Total de ingressos vendidos:";
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("HoloLens MDL2 Assets", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(293, 30);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(115, 27);
            this.label3.TabIndex = 3;
            this.label3.Text = "Data do evento: ";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Gold;
            this.panel3.Controls.Add(this.pictureBox7);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(183, 232);
            this.panel3.TabIndex = 12;
            // 
            // Recarregar
            // 
            this.Recarregar.BackColor = System.Drawing.Color.Transparent;
            this.Recarregar.BackgroundImage = global::Home.Properties.Resources.reload;
            this.Recarregar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Recarregar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Recarregar.FlatAppearance.BorderSize = 0;
            this.Recarregar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Recarregar.ForeColor = System.Drawing.Color.Coral;
            this.Recarregar.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Recarregar.Location = new System.Drawing.Point(615, 152);
            this.Recarregar.Name = "Recarregar";
            this.Recarregar.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Recarregar.Size = new System.Drawing.Size(37, 29);
            this.Recarregar.TabIndex = 11;
            this.Recarregar.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.Recarregar.UseMnemonic = false;
            this.Recarregar.UseVisualStyleBackColor = false;
            this.Recarregar.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Home.Properties.Resources.carrinho_de_compras;
            this.pictureBox4.Location = new System.Drawing.Point(144, 113);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(24, 23);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 13;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(144, 60);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(25, 34);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 4;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackColor = System.Drawing.Color.White;
            this.pictureBox9.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox9.Image")));
            this.pictureBox9.Location = new System.Drawing.Point(147, 553);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(21, 17);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox9.TabIndex = 14;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(144, 9);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(24, 25);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.ErrorImage")));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.InitialImage")));
            this.pictureBox1.Location = new System.Drawing.Point(146, 166);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(22, 24);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8.Image")));
            this.pictureBox8.Location = new System.Drawing.Point(111, 106);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(19, 25);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox8.TabIndex = 12;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(40, 8);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(90, 103);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 3;
            this.pictureBox7.TabStop = false;
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Yellow;
            this.ClientSize = new System.Drawing.Size(1184, 761);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel3);
            this.Name = "Home";
            this.Text = "Gerenciamento de eventos";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.UltimasVendasdataGridView1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button ConsultarAlunos;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button RegistrarVenda;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button NovoAlunobutton;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button Sair;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.Button ConsultarCompras;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView UltimasVendasdataGridView1;
        private System.Windows.Forms.Label QuantLabel;
        private System.Windows.Forms.Label EstoqueLabel;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Button Recarregar;
    }
}

