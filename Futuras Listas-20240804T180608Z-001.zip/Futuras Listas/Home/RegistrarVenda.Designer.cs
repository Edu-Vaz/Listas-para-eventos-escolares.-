﻿namespace Home
{
    partial class RegistrarVenda
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Voltarbutton = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Limpar = new System.Windows.Forms.Button();
            this.RegistrarVendabutton = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.PesquisarMAbutton = new System.Windows.Forms.Button();
            this.pesquisarNomeBTN = new System.Windows.Forms.Button();
            this.AlunoslistBox1 = new System.Windows.Forms.ListBox();
            this.QuanttextBox3 = new System.Windows.Forms.TextBox();
            this.MatextBox2 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.NometextBox1 = new System.Windows.Forms.TextBox();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(143, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Pesquise o aluno pelo nome:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 198);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Quantidade:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(19, 240);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Data da Compra:";
            // 
            // Voltarbutton
            // 
            this.Voltarbutton.Location = new System.Drawing.Point(4, 7);
            this.Voltarbutton.Name = "Voltarbutton";
            this.Voltarbutton.Size = new System.Drawing.Size(75, 23);
            this.Voltarbutton.TabIndex = 5;
            this.Voltarbutton.Text = "Voltar";
            this.Voltarbutton.UseVisualStyleBackColor = true;
            this.Voltarbutton.Click += new System.EventHandler(this.Voltarbutton_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.Limpar);
            this.panel1.Controls.Add(this.RegistrarVendabutton);
            this.panel1.Location = new System.Drawing.Point(-1, 407);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(801, 40);
            this.panel1.TabIndex = 6;
            // 
            // Limpar
            // 
            this.Limpar.Location = new System.Drawing.Point(13, 12);
            this.Limpar.Name = "Limpar";
            this.Limpar.Size = new System.Drawing.Size(123, 23);
            this.Limpar.TabIndex = 12;
            this.Limpar.Text = "Limpar";
            this.Limpar.UseVisualStyleBackColor = true;
            this.Limpar.Click += new System.EventHandler(this.Limpar_Click);
            // 
            // RegistrarVendabutton
            // 
            this.RegistrarVendabutton.Location = new System.Drawing.Point(666, 12);
            this.RegistrarVendabutton.Name = "RegistrarVendabutton";
            this.RegistrarVendabutton.Size = new System.Drawing.Size(123, 23);
            this.RegistrarVendabutton.TabIndex = 11;
            this.RegistrarVendabutton.Text = "Registrar Venda";
            this.RegistrarVendabutton.UseVisualStyleBackColor = true;
            this.RegistrarVendabutton.Click += new System.EventHandler(this.RegistrarVendabutton_Click_1);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.PesquisarMAbutton);
            this.panel2.Controls.Add(this.pesquisarNomeBTN);
            this.panel2.Controls.Add(this.AlunoslistBox1);
            this.panel2.Controls.Add(this.QuanttextBox3);
            this.panel2.Controls.Add(this.MatextBox2);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.NometextBox1);
            this.panel2.Controls.Add(this.monthCalendar1);
            this.panel2.Controls.Add(this.Voltarbutton);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(2, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(790, 410);
            this.panel2.TabIndex = 7;
            // 
            // PesquisarMAbutton
            // 
            this.PesquisarMAbutton.Location = new System.Drawing.Point(173, 148);
            this.PesquisarMAbutton.Name = "PesquisarMAbutton";
            this.PesquisarMAbutton.Size = new System.Drawing.Size(123, 23);
            this.PesquisarMAbutton.TabIndex = 14;
            this.PesquisarMAbutton.Text = "Pesquisar por MA";
            this.PesquisarMAbutton.UseVisualStyleBackColor = true;
            this.PesquisarMAbutton.Click += new System.EventHandler(this.PesquisarMAbutton_Click_1);
            // 
            // pesquisarNomeBTN
            // 
            this.pesquisarNomeBTN.Location = new System.Drawing.Point(173, 75);
            this.pesquisarNomeBTN.Name = "pesquisarNomeBTN";
            this.pesquisarNomeBTN.Size = new System.Drawing.Size(123, 23);
            this.pesquisarNomeBTN.TabIndex = 13;
            this.pesquisarNomeBTN.Text = "Pesquisar por nome";
            this.pesquisarNomeBTN.UseVisualStyleBackColor = true;
            this.pesquisarNomeBTN.Click += new System.EventHandler(this.pesquisar_Click);
            // 
            // AlunoslistBox1
            // 
            this.AlunoslistBox1.FormattingEnabled = true;
            this.AlunoslistBox1.Location = new System.Drawing.Point(470, 10);
            this.AlunoslistBox1.Name = "AlunoslistBox1";
            this.AlunoslistBox1.Size = new System.Drawing.Size(301, 381);
            this.AlunoslistBox1.TabIndex = 11;
            // 
            // QuanttextBox3
            // 
            this.QuanttextBox3.Location = new System.Drawing.Point(91, 198);
            this.QuanttextBox3.Name = "QuanttextBox3";
            this.QuanttextBox3.Size = new System.Drawing.Size(83, 20);
            this.QuanttextBox3.TabIndex = 10;
            // 
            // MatextBox2
            // 
            this.MatextBox2.Location = new System.Drawing.Point(173, 122);
            this.MatextBox2.Name = "MatextBox2";
            this.MatextBox2.Size = new System.Drawing.Size(83, 20);
            this.MatextBox2.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(24, 122);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(133, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "Pesquise o aluno pelo MA:";
            // 
            // NometextBox1
            // 
            this.NometextBox1.Location = new System.Drawing.Point(173, 49);
            this.NometextBox1.Name = "NometextBox1";
            this.NometextBox1.Size = new System.Drawing.Size(240, 20);
            this.NometextBox1.TabIndex = 7;
            this.NometextBox1.TextChanged += new System.EventHandler(this.NometextBox1_TextChanged);
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.Location = new System.Drawing.Point(115, 230);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.TabIndex = 6;
            // 
            // RegistrarVenda
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "RegistrarVenda";
            this.Text = "Form2";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button Voltarbutton;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox QuanttextBox3;
        private System.Windows.Forms.TextBox MatextBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox NometextBox1;
        private System.Windows.Forms.Button Limpar;
        private System.Windows.Forms.Button RegistrarVendabutton;
        private System.Windows.Forms.ListBox AlunoslistBox1;
        private System.Windows.Forms.Button pesquisarNomeBTN;
        private System.Windows.Forms.Button PesquisarMAbutton;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
    }
}