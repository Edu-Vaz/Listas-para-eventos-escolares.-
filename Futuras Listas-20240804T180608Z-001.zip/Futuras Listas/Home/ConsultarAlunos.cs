﻿using ListaDB;
using Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Home
{
    public partial class ConsultarAlunos : Form
    {
        public ConsultarAlunos()
        {
            InitializeComponent();
        }

        private void Pesquisarbutton_Click(object sender, EventArgs e)
        {
            var alunos = new AlunosDB();
            List<Alunos> resultadoPesquisa = new List<Alunos>();
            if (!string.IsNullOrEmpty(nometextBox.Text))
            {
                string nomeSobrenome = nometextBox.Text;
                resultadoPesquisa = AlunosDB.Pesquisar_nome_Alunos(nomeSobrenome);
                
            }

            

            else
            {
               

                int ma = Convert.ToInt32(matextBox.Text);

                // Supondo que você tenha uma instância da classe com o método Pesquisar_nome_Alunos
               resultadoPesquisa = AlunosDB.Pesquisar_nome_Alunos(ma);
            }
            dataGridView1.DataSource = resultadoPesquisa;
        }

        private void ConsultarAlunos_Load(object sender, EventArgs e)
        {
            var aluno = new AlunosDB();
            List<Alunos> resultadoPesquisa = AlunosDB.Listar_Alunos();
            dataGridView1.DataSource = resultadoPesquisa;
        }

        private void Ordenar_Click(object sender, EventArgs e)
        {
            var aluno = new AlunosDB();
            List<Alunos> resultadoPesquisa = AlunosDB.Listar_Alunos();
            dataGridView1.DataSource = resultadoPesquisa;

        }
    }
}
