﻿using ListaDB;
using Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Home
{
    public partial class Novo_Aluno : Form
    {
        public Novo_Aluno()
        {
            InitializeComponent();
        }

        private void GravarButton_Click(object sender, EventArgs e)
        {
            var aluno = new Alunos();
            aluno.MA =Convert.ToInt32(MaTextBox.Text);
            aluno.Nome = NomeTextBox.Text;
            aluno.Serie = SerieTextBox.Text;
            aluno.Chamada = ChamadaTextBox.Text;
            aluno.Quantidade_Ingressos=Convert.ToInt32(QuanttextBox.Text);

            var alunoDB = new AlunosDB();
            alunoDB.Novo_aluno(aluno);
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MaTextBox.Clear();
            NomeTextBox.Clear();
            SerieTextBox.Clear();
            ChamadaTextBox.Clear();
            QuanttextBox.Clear();
        }

        private void voltar_Click(object sender, EventArgs e)
        {
            Home novoFormulario = new Home();

            // Exibir o novo formulário
            novoFormulario.Show();
        }
    }
}
