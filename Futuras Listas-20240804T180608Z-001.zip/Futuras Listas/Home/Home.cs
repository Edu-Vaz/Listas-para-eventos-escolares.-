﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ListaDB;

namespace Home
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void NovoAlunobutton_Click(object sender, EventArgs e)
        {
            // Criar uma instância do novo formulário
            Novo_Aluno  novoFormulario = new Novo_Aluno();

            // Exibir o novo formulário
            novoFormulario.Show();
        }

        private void RegistrarVenda_Click(object sender, EventArgs e)
        {
            RegistrarVenda novoFormulario = new RegistrarVenda();

            // Exibir o novo formulário
            novoFormulario.Show();
        }

        private void ConsultarAlunos_Click(object sender, EventArgs e)
        {
            ConsultarAlunos novoFormulario = new ConsultarAlunos();

            // Exibir o novo formulário
            novoFormulario.Show();
        }

        private void ConsultarCompras_Click(object sender, EventArgs e)
        {
            ConsultarCompras novoFormulario = new ConsultarCompras();

            // Exibir o novo formulário
            novoFormulario.Show();
        }

        private void Sair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        // No seu Form1_Load
        private void Form1_Load(object sender, EventArgs e)
        {
            int quantidadeEstoque = EstoqueDB.Listar_Estoque();
            EstoqueLabel.Text = quantidadeEstoque.ToString();

            int quantidadeIngressos = AlunosDB.qtd_ingressosComprados();
            QuantLabel.Text = quantidadeIngressos.ToString();

            // Carregar as últimas vendas
            var ultimasVendas = VendaDB.Listar_Ulti_Vendas();

            // Definir as colunas que serão exibidas no DataGridView
            UltimasVendasdataGridView1.AutoGenerateColumns = false;

            // Adicionar as colunas desejadas
            UltimasVendasdataGridView1.Columns.Add(new DataGridViewTextBoxColumn()
            {
                DataPropertyName = "VendaData",
                HeaderText = "Data da Venda"
            });

            UltimasVendasdataGridView1.Columns.Add(new DataGridViewTextBoxColumn()
            {
                DataPropertyName = "Quantidade",
                HeaderText = "Quantidade Vendida"
            });

            UltimasVendasdataGridView1.Columns.Add(new DataGridViewTextBoxColumn()
            {
                DataPropertyName = "AlunoNome",
                HeaderText = "Nome do Aluno"
            });

            UltimasVendasdataGridView1.Columns.Add(new DataGridViewTextBoxColumn()
            {
                DataPropertyName = "AlunoSerie",
                HeaderText = "Série do Aluno"
            });

            UltimasVendasdataGridView1.Columns.Add(new DataGridViewTextBoxColumn()
            {
                DataPropertyName = "AlunoQuantidadeIngressos",
                HeaderText = "Ingressos Comprados pelo Aluno"
            });

            // Associar a lista de vendas ao DataGridView
            UltimasVendasdataGridView1.DataSource = ultimasVendas.Select(v => new
            {
                VendaData = v.Venda.Data,
                Quantidade = v.Venda.Quantidade,
                AlunoNome = v.Aluno.Nome,
                AlunoSerie = v.Aluno.Serie,
                AlunoQuantidadeIngressos = v.Aluno.Quantidade_Ingressos
            }).ToList();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            UltimasVendasdataGridView1.Rows.Clear();
            int quantidadeEstoque = EstoqueDB.Listar_Estoque();
            EstoqueLabel.Text = quantidadeEstoque.ToString();

            int quantidadeIngressos = AlunosDB.qtd_ingressosComprados();
            QuantLabel.Text = quantidadeIngressos.ToString();

            // Carregar as últimas vendas
            var ultimasVendas = VendaDB.Listar_Ulti_Vendas();

            // Definir as colunas que serão exibidas no DataGridView
            UltimasVendasdataGridView1.AutoGenerateColumns = false;

            // Adicionar as colunas desejadas
            UltimasVendasdataGridView1.Columns.Add(new DataGridViewTextBoxColumn()
            {
                DataPropertyName = "VendaData",
                HeaderText = "Data da Venda"
            });

            UltimasVendasdataGridView1.Columns.Add(new DataGridViewTextBoxColumn()
            {
                DataPropertyName = "Quantidade",
                HeaderText = "Quantidade Vendida"
            });

            UltimasVendasdataGridView1.Columns.Add(new DataGridViewTextBoxColumn()
            {
                DataPropertyName = "AlunoNome",
                HeaderText = "Nome do Aluno"
            });

            UltimasVendasdataGridView1.Columns.Add(new DataGridViewTextBoxColumn()
            {
                DataPropertyName = "AlunoSerie",
                HeaderText = "Série do Aluno"
            });

            UltimasVendasdataGridView1.Columns.Add(new DataGridViewTextBoxColumn()
            {
                DataPropertyName = "AlunoQuantidadeIngressos",
                HeaderText = "Ingressos Comprados pelo Aluno"
            });

            // Associar a lista de vendas ao DataGridView
            UltimasVendasdataGridView1.DataSource = ultimasVendas.Select(v => new
            {
                VendaData = v.Venda.Data,
                Quantidade = v.Venda.Quantidade,
                AlunoNome = v.Aluno.Nome,
                AlunoSerie = v.Aluno.Serie,
                AlunoQuantidadeIngressos = v.Aluno.Quantidade_Ingressos
            }).ToList();
        }

        private void UltimasVendasdataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
