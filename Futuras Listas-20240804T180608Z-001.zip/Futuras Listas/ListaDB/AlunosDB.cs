﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Models;

namespace ListaDB
{
    public class AlunosDB : Alunos
    {
        public static string Conectar =
             @"Data Source=DESKTOP-DSHPLAD\SQLEXPRESS;
            Initial Catalog=""projeto convites testes"";Integrated Security=True;";

        public static List<Alunos> Listar_Alunos()
        {
            var cn = new SqlConnection();
            cn.ConnectionString = Conectar;
            var cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandText = "SELECT * FROM Alunos Order By Serie,Nome";
            List<Alunos> lista = new List<Alunos>();
            cn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                var aluno = new Alunos();
                aluno.MA = Convert.ToInt32(reader["ma"]);
                aluno.Nome = reader["Nome"].ToString();
                aluno.Serie = reader["Serie"].ToString();
                aluno.Chamada = reader["Chamada"].ToString();
                aluno.Quantidade_Ingressos = Convert.ToInt32(reader["ingressos_comprados"]);

                lista.Add(aluno);

            }

            reader.Close();
            cn.Close();
            return lista;

        }
        public void Novo_aluno(Alunos aluno)
        {
            var cn = new SqlConnection();
            cn.ConnectionString = Conectar;

            var cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandText = "insert into Alunos(MA,nome,serie,chamada) Values (@ma,@nome,@serie,@chamada)";
            cmd.Parameters.AddWithValue("@ma", aluno.MA);
            cmd.Parameters.AddWithValue("@nome", aluno.Nome);
            cmd.Parameters.AddWithValue("@serie", aluno.Serie);
            cmd.Parameters.AddWithValue("@chamada", aluno.Chamada);
            cmd.Parameters.AddWithValue("@Ingressos_Comprados", aluno.Quantidade_Ingressos);
            cn.Open();
            int total = cmd.ExecuteNonQuery();
            cn.Close();
        }
        public static int qtd_ingressosComprados()
        {
            var aluno = new Alunos();
            var cn = new SqlConnection();
            cn.ConnectionString = Conectar;
            var cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandText = "select sum(Ingressos_Comprados) as ingressos from Alunos";
            cn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            int quantidade = 0;
            while (reader.Read())
            {
                quantidade = aluno.Quantidade_Ingressos = Convert.ToInt32(reader["ingressos"]);
            }

            reader.Close();
            cn.Close();
            return quantidade;
        }
        public static List<Alunos> Pesquisar_nome_Alunos(string NomeSobrenome)
        {
            return Pesquisar_nome_Alunos(NomeSobrenome, null);
        }

        public static List<Alunos> Pesquisar_nome_Alunos(int ma)
        {
            return Pesquisar_nome_Alunos(null, ma);
        }

        public static List<Alunos> Pesquisar_nome_Alunos(string NomeSobrenome, int? ma)
        {
            var cn = new SqlConnection();
            cn.ConnectionString = Conectar;
            var cmd = new SqlCommand();
            cmd.Connection = cn;

            string query = "SELECT * FROM Alunos WHERE 1=1";

            if (!string.IsNullOrEmpty(NomeSobrenome))
            {
                query += " AND Nome LIKE @NomeCompleto";
                cmd.Parameters.AddWithValue("@NomeCompleto", "%" + NomeSobrenome.ToUpper() + "%");
            }

            if (ma.HasValue)
            {
                query += " AND MA = @MA";
                cmd.Parameters.AddWithValue("@MA", ma.Value);
            }

            cmd.CommandText = query + " Order By Serie, Nome";

            List<Alunos> lista = new List<Alunos>();
            cn.Open();

            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                var aluno = new Alunos();
                aluno.MA = Convert.ToInt32(reader["ma"]);
                aluno.Nome = reader["Nome"].ToString();
                aluno.Serie = reader["Serie"].ToString();
                aluno.Chamada = reader["Chamada"].ToString();
                aluno.Quantidade_Ingressos = Convert.ToInt32(reader["Ingressos_comprados"]);

                lista.Add(aluno);
            }

            reader.Close();
            cn.Close();
            return lista;
        }
    }
    
}
