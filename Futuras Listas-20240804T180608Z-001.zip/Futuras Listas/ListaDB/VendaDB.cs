﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Models;

namespace ListaDB
{
    public class VendaDB : Venda
    {
        public static string Conectar =
    @"Data Source=DESKTOP-DSHPLAD\SQLEXPRESS;Initial Catalog=""projeto convites testes"";Integrated Security=True;";
        public void Registrar_Venda(Venda venda) 
        {
            var cn = new SqlConnection();
            cn.ConnectionString = Conectar;
            var cmd = cn.CreateCommand();
            cmd.Connection = cn;
            cmd.CommandText = "INSERT INTO COMPRA (data_compra, " +
            "quant_ingressos, ma) VALUES (@data_compra, @quant_ingressos, @ma)";
            cmd.Parameters.AddWithValue("@data_compra", venda.Data);
            
            cmd.Parameters.AddWithValue("@quant_ingressos", venda.Quantidade);
            cmd.Parameters.AddWithValue("@ma", venda.Ma);
            cn.Open();
            int total = cmd.ExecuteNonQuery();
            cn.Close();
            
            cmd.CommandText = "UPDATE Alunos SET Ingressos_Comprados += @quantidade WHERE MA = @maAluno";
            cmd.Parameters.AddWithValue("@quantidade", venda.Quantidade);
            cmd.Parameters.AddWithValue("@maAluno", venda.Ma);
            cn.Open();
            total = cmd.ExecuteNonQuery();
            cn.Close();

            cmd.CommandText = "UPDATE Estoque SET estoque -= @quant_ingressoss WHERE id = 2";
            cmd.Parameters.AddWithValue("@quant_ingressoss", venda.Quantidade);
            
            cn.Open();
            total = cmd.ExecuteNonQuery();
            cn.Close();
        }
        public List<VendaAluno> Listar_Vendas(string opcao)
        {
            var cn = new SqlConnection();
            cn.ConnectionString = Conectar;
            var cmd = new SqlCommand();
            cmd.Connection = cn;

            if (opcao == "Data")
            {
                cmd.CommandText = "SELECT data_compra, quant_ingressos, Nome, serie, ingressos_comprados FROM Compra as c" +
                    " JOIN alunos as a ON a.ma = c.ma ORDER BY data_compra, nome";
            }
            else if (opcao == "serie")
            {
                cmd.CommandText = "SELECT data_compra, quant_ingressos, Nome, serie, ingressos_comprados FROM Compra as c" +
                    " JOIN alunos as a ON a.ma = c.ma ORDER BY serie, nome";
            }
            else
            {
                cmd.CommandText = "SELECT data_compra, quant_ingressos, ma, Nome, serie, ingressos_comprados FROM Compra as c" +
                    " JOIN alunos as a ON a.ma = c.ma ORDER BY nome";
            }

            List<VendaAluno> lista = new List<VendaAluno>();
            cn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                var venda = new Venda();
                venda.Data = reader["data_compra"].ToString();
                venda.Quantidade = Convert.ToInt32(reader["quant_ingressos"]);

                var aluno = new Alunos();
                aluno.MA = Convert.ToInt32(reader["ma"]);
                aluno.Nome = reader["Nome"].ToString();
                aluno.Serie = reader["Serie"].ToString();
                aluno.Chamada = reader["Chamada"].ToString();
                aluno.Quantidade_Ingressos = Convert.ToInt32(reader["Ingressos_comprados"]);

                var vendaAluno = new VendaAluno(venda, aluno);
                lista.Add(vendaAluno);
            }

            reader.Close();
            cn.Close();
            return lista;

        }

        public static List<VendaAluno> Listar_Ulti_Vendas()
        {
            var cn = new SqlConnection();
            cn.ConnectionString = Conectar;
            var cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandText = "SELECT TOP 5 c.data_compra, c.quant_ingressos, a.Nome, a.serie, a.ingressos_comprados " +
                             "FROM Compra AS c " +
                             "JOIN alunos AS a ON a.ma = c.ma " +
                             "ORDER BY c.data_compra DESC";

            List<VendaAluno> lista = new List<VendaAluno>();
            cn.Open();
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                var venda = new Venda();
                venda.Data = reader["data_compra"].ToString();
                venda.Quantidade = Convert.ToInt32(reader["quant_ingressos"]);

                var aluno = new Alunos();
                aluno.Nome = reader["Nome"].ToString();
                aluno.Serie = reader["serie"].ToString();
                aluno.Quantidade_Ingressos = Convert.ToInt32(reader["ingressos_comprados"]);

                // Crie um novo objeto VendaAluno passando os objetos Venda e Alunos criados acima
                var vendaAluno = new VendaAluno(venda, aluno);
                lista.Add(vendaAluno);
            }

            reader.Close();
            cn.Close();
            return lista;
        }
    }

}
