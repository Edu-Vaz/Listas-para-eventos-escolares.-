﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models;

namespace ListaDB
{
    public class EstoqueDB : Estoque
    {
        public static string Conectar =
            @"Data Source=DESKTOP-DSHPLAD\SQLEXPRESS;Initial Catalog=""projeto convites testes"";Integrated Security=True;";

        public void Incluir()
        {
            var cn = new SqlConnection();
            cn.ConnectionString = Conectar;
            var estoque = new Estoque();
            var cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandText = "insert into Estoque(id,estoque) Values (@id,@estoque)";
            cmd.Parameters.AddWithValue("@id", estoque.Id);
            cmd.Parameters.AddWithValue("@Nome", estoque.Quantidade);
            cn.Open();
            int total = cmd.ExecuteNonQuery();
            cn.Close();
        }
        public static int Listar_Estoque()
        {
            var cn = new SqlConnection();
            cn.ConnectionString = Conectar;
            var cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandText = "SELECT * FROM Estoque ";
            int quant = 0;
            cn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                var estoque = new Estoque();
                quant=estoque.Quantidade = Convert.ToInt32(reader["Estoque"]);
                
            }

            reader.Close();
            cn.Close();
            return quant;

        }

    }    
}
