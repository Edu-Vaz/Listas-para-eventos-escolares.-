﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models
{
    
     public class VendaAluno
     {
            public Venda Venda { get; set; }
            public Alunos Aluno { get; set; }

            public VendaAluno(Venda venda, Alunos aluno)
            {
                Venda = venda;
                Aluno = aluno;
            }
     }
}
